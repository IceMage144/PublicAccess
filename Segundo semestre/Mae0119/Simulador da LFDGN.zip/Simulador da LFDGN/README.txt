Simulador da lei fraca dos grandes números

Nome: João Gabriel Basi
N° USP: 9793801

Pré-reqisitos:
No meu computador não foi necessário a instalação de nenhum outro arquivo, porém
o programa depende de alguns packages instalados. Eles podem ser vistos na seção
"Installing dependencies" do site http://www.sfml-dev.org/tutorials/2.4/compile-with-cmake.php
Somente alguns são necessários para executar o programa. Fiz alguns testes na rede linux e
aparentemente a biblioteca só usa o jpeg e o x11.

Como executar:
Acesse pelo terminal a pasta que contém o arquivo "Simulador_da_LFDGN.cpp" e rode o
comando "make exec" (sem aspas) no terminal.

Erros:
Se algum erro acontecer, ele falará de alguma função que o programa precisa para executar.
Antes do nome da função aparece o nome da biblioteca que falta, sendo assim, é só instalá-la
para que o programa execute.
